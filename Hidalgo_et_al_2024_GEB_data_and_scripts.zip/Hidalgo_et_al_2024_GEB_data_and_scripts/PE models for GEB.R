############################################
# Portfolio models from surveys (WGCOMEDA) #
############################################

# --- Meaning of each Variable --- # 
# plotOrd: System ID for ordering
# Region: Region Name
# System: System Name
# Latitude: Mean latitude
# Longitude: Mean longitude
# MV_PE: Mean-Variance Portfolio Effect
# ci1_MV_PE: Low for MVPE
# ci2_MV_PE: Upp for MVPE
# AvCV_PE: Average CV Portfolio Effect
# ci1_AvCV_PE: Low for CVPE
# ci2_AvCV_PE: Upp for CVPE
# z: Z-value
# ci_z: CI for z-value
# syn: synchrony
# rich: mean richness
# div: mean Shannon diversity
# even: mean evenness
# K: CWM_k
# L50: CWM_L50
# TL: CWM_TL
# Depth: Mean depth
# DepthCV: Depth CV
# Chla: Mean Chla (log)
# ChlaCV: Chla CV
# SBT: mean SBT
# SBTrange: SBT range (log)
# TAI: Total Anthropogenic Impact
# Trawl: Bottom Trawling (log)
# InterceptRich: Intercept for Richness LME
# SlopeRich: Slope for Richness LME
# InterceptEven: Intercept for Evenness LME
# SlopeEven: Slope for Evenness LME
# cpueME: mean CPUE

library(tidyverse)
library(lavaan)
library(lavaanPlot)
library(piecewiseSEM)
library(semTools)
library(patchwork)
library(cowplot)
library(car)
library(maps)
library(nlme)
library(ggrepel)
library(corrr)

MyStd<-function (x) {(x-mean(x,na.rm=T))/sd(x,na.rm=T)}

m.world<-map_data("world")


# ------------------------------------------------------ #
#1# Read data

# Set working directory!!

portfolio<-read.csv2(file="portfolioDataForGEB.csv",header=T,dec=",",sep=",")

head(portfolio)
dim(portfolio)
names(portfolio)

#1.1# Plot mid location of each system 

ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray60",col="black")+
  coord_cartesian(xlim=c(-95,40),ylim=c(15,70))+
  geom_point(size=4,col=2)+
  geom_text_repel(aes(x=Longitude,y=Latitude,label=System),col="blue")

#1.2# Explore correlation between CPUE, taxonomic and functional diversity with the environment

portfolio %>% 
  select(c(33,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(cpueME)

portfolio %>% 
  select(c(15,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(rich)

portfolio %>% 
  select(c(16,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(div)

portfolio %>% 
  select(c(17,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(even)

portfolio %>% 
  select(c(18,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(K)

portfolio %>% 
  select(c(19,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(L50)

portfolio %>% 
  select(c(20,21:26)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(TL)

#1.3# Plot the most relevant relationships

p1<-ggplot(data=portfolio,aes(x=Depth,y=log(cpueME)))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous(expression(paste("ln-Abundance (ind × ",km^-2,")")))+
  scale_x_continuous("Depth (m)")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position=c(1,0.05),legend.justification=c("right","bottom"),
        axis.text=element_text(size=14),axis.title=element_text(size=16),
        legend.text=element_text(size=8),legend.title=element_text(size=9),
        legend.key.spacing.y=unit(0.01,"pt"))+
  ggtitle("(A)")

p2<-ggplot(data=portfolio,aes(x=Chla,y=log(cpueME)))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("")+
  scale_x_continuous("Mean Chla")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

p3<-ggplot(data=portfolio,aes(x=SBT,y=log(cpueME)))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50",linetype="dashed")+
  scale_y_continuous("")+
  scale_x_continuous("SBT (ºC)")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

p4<-ggplot(data=portfolio,aes(x=SBT,y=rich))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50",linetype="dashed")+
  scale_y_continuous("Richness")+
  scale_x_continuous("")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

p5<-ggplot(data=portfolio,aes(x=SBT,y=div))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Shannon diversity")+
  scale_x_continuous("")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

p6<-ggplot(data=portfolio,aes(x=SBT,y=even))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Evenness")+
  scale_x_continuous("")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

p7<-ggplot(data=portfolio,aes(x=SBT,y=K))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous(expression(CWM[K]))+
  scale_x_continuous("SBT (ºC)")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

p8<-ggplot(data=portfolio,aes(x=SBT,y=L50))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous(expression(CWM[L50]))+
  scale_x_continuous("SBT (ºC)")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

p9<-ggplot(data=portfolio,aes(x=SBT,y=TL))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous(expression(CWM[TL]))+
  scale_x_continuous("SBT (ºC)")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

pdf(file="Abund_Div_Env_1.pdf",width=12,height=11)
(p1+p2+p3)/(p4+p5+p6)/(p7+p8+p9)
dev.off()

p10<-ggplot(data=portfolio,aes(x=SBTrange,y=log(cpueME)))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous(expression(paste("ln-Abundance (ind × ",km^-2,")")))+
  scale_x_continuous("SBT range")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

p11<-ggplot(data=portfolio,aes(x=ChlaCV,y=rich))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Richness")+
  scale_x_continuous("ChlaCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

p12<-ggplot(data=portfolio,aes(x=DepthCV,y=div))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Shannon diversity")+
  scale_x_continuous("DepthCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

p13<-ggplot(data=portfolio,aes(x=DepthCV,y=even))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Evenness")+
  scale_x_continuous("DepthCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

pdf(file="Abund_Div_Env_2.pdf",width=8,height=7)
(p10+p11)/(p12+p13)
dev.off()

#1.4# Simple linear models

#1.4.1# Abundance models

lm1<-lm(log(cpueME)~Depth,data=portfolio,na.action=na.exclude)
summary(lm1)

lm2<-lm(log(cpueME)~Chla,data=portfolio,na.action=na.exclude)
summary(lm2)

lm3<-lm(log(cpueME)~SBT,data=portfolio,na.action=na.exclude)
summary(lm3)

lm4<-lm(log(cpueME)~SBTrange,data=portfolio,na.action=na.exclude)
summary(lm4)

#1.4.2# Richness models

lm5<-lm(rich~SBT,data=portfolio,na.action=na.exclude)
summary(lm5)

lm6<-lm(rich~ChlaCV,data=portfolio,na.action=na.exclude)
summary(lm6)

#1.4.3# Shannon models

lm7<-lm(div~SBT,data=portfolio,na.action=na.exclude)
summary(lm7)

lm8<-lm(div~DepthCV,data=portfolio,na.action=na.exclude)
summary(lm8)

#1.4.4# Evenness models

lm9<-lm(even~SBT,data=portfolio,na.action=na.exclude)
summary(lm9)

lm10<-lm(even~DepthCV,data=portfolio,na.action=na.exclude)
summary(lm10)

#1.4.5# CWMs models

lm11<-lm(K~SBT,data=portfolio,na.action=na.exclude)
summary(lm11)

lm12<-lm(L50~SBT,data=portfolio,na.action=na.exclude)
summary(lm12)

lm13<-lm(TL~SBT,data=portfolio,na.action=na.exclude)
summary(lm13)

#1.5# Residuals plots

portfolio$residLM1<-residuals(lm1) # cpue~depth
portfolio$residLM2<-residuals(lm2) # cpue~chla
portfolio$residLM3<-residuals(lm3) # cpue~sbt
portfolio$residLM4<-residuals(lm4) # cpue~sbtrange
portfolio$residLM5<-residuals(lm5) # rich~sbt
portfolio$residLM6<-residuals(lm6) # rich~chlacv
portfolio$residLM7<-residuals(lm7) # div~sbt
portfolio$residLM8<-residuals(lm8) # div~depthcv
portfolio$residLM9<-residuals(lm9) # even~sbt
portfolio$residLM10<-residuals(lm10) # even~depthcv
portfolio$residLM11<-residuals(lm11) # K~sbt
portfolio$residLM12<-residuals(lm12) # L50~sbt
portfolio$residLM13<-residuals(lm13) # TL~sbt

portfolio$fitLM1<-fitted(lm1)
portfolio$fitLM2<-fitted(lm2)
portfolio$fitLM3<-fitted(lm3)
portfolio$fitLM4<-fitted(lm4)
portfolio$fitLM5<-fitted(lm5)
portfolio$fitLM6<-fitted(lm6)
portfolio$fitLM7<-fitted(lm7)
portfolio$fitLM8<-fitted(lm8)
portfolio$fitLM9<-fitted(lm9)
portfolio$fitLM10<-fitted(lm10)
portfolio$fitLM11<-fitted(lm11)
portfolio$fitLM12<-fitted(lm12)
portfolio$fitLM13<-fitted(lm13)

reLM1<-ggplot(data=portfolio,aes(x=fitLM1,y=residLM1))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM2<-ggplot(data=portfolio,aes(x=residLM1))+
  geom_histogram(binwidth=1)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM3<-ggplot(data=filter(portfolio,residLM1 != "NA"),
              aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM1),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM4<-ggplot(data=portfolio,aes(x=fitLM2,y=residLM2))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM5<-ggplot(data=portfolio,aes(x=residLM2))+
  geom_histogram(binwidth=0.7)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM6<-ggplot(data=filter(portfolio,residLM2 != "NA"),
              aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM2),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM7<-ggplot(data=portfolio,aes(x=fitLM3,y=residLM3))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM8<-ggplot(data=portfolio,aes(x=residLM3))+
  geom_histogram(binwidth=0.6)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM9<-ggplot(data=filter(portfolio,residLM3 != "NA"),
              aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM3),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM10<-ggplot(data=portfolio,aes(x=fitLM4,y=residLM4))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="Fitted")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM11<-ggplot(data=portfolio,aes(x=residLM4))+
  geom_histogram(binwidth=1)+
  labs(y="Count",x="Residuals")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM12<-ggplot(data=filter(portfolio,residLM4 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM4),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="Longitude (ºW-E)")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM13<-ggplot(data=portfolio,aes(x=fitLM5,y=residLM5))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM14<-ggplot(data=portfolio,aes(x=residLM5))+
  geom_histogram(binwidth=5)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM15<-ggplot(data=filter(portfolio,residLM5 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM5),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM16<-ggplot(data=portfolio,aes(x=fitLM6,y=residLM6))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM17<-ggplot(data=portfolio,aes(x=residLM6))+
  geom_histogram(binwidth=5)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM18<-ggplot(data=filter(portfolio,residLM6 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM6),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM19<-ggplot(data=portfolio,aes(x=fitLM7,y=residLM7))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM20<-ggplot(data=portfolio,aes(x=residLM7))+
  geom_histogram(binwidth=0.25)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM21<-ggplot(data=filter(portfolio,residLM7 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM7),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM22<-ggplot(data=portfolio,aes(x=fitLM8,y=residLM8))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM23<-ggplot(data=portfolio,aes(x=residLM8))+
  geom_histogram(binwidth=0.2)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM24<-ggplot(data=filter(portfolio,residLM8 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM8),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM25<-ggplot(data=portfolio,aes(x=fitLM9,y=residLM9))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM26<-ggplot(data=portfolio,aes(x=residLM9))+
  geom_histogram(binwidth=0.1)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM27<-ggplot(data=filter(portfolio,residLM9 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM9),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM28<-ggplot(data=portfolio,aes(x=fitLM10,y=residLM10))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="Fitted")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM29<-ggplot(data=portfolio,aes(x=residLM10))+
  geom_histogram(binwidth=0.07)+
  labs(y="Count",x="Residuals")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM30<-ggplot(data=filter(portfolio,residLM10 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM10),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="Longitude (ºW-E)")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM31<-ggplot(data=portfolio,aes(x=fitLM11,y=residLM11))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM32<-ggplot(data=portfolio,aes(x=residLM11))+
  geom_histogram(binwidth=0.05)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM33<-ggplot(data=filter(portfolio,residLM11 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM11),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM34<-ggplot(data=portfolio,aes(x=fitLM12,y=residLM12))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM35<-ggplot(data=portfolio,aes(x=residLM12))+
  geom_histogram(binwidth=3)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM36<-ggplot(data=filter(portfolio,residLM12 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM12),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM37<-ggplot(data=portfolio,aes(x=fitLM13,y=residLM13))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="Fitted")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM38<-ggplot(data=portfolio,aes(x=residLM13))+
  geom_histogram(binwidth=0.1)+
  labs(y="Count",x="Residuals")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

reLM39<-ggplot(data=filter(portfolio,residLM13 != "NA"),
               aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residLM13),size=3)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="Longitude (ºW-E)")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))

pdf(file="resid_LM1.pdf",width=12,height=14)
(reLM1+reLM2+reLM3)/(reLM4+reLM5+reLM6)/(reLM7+reLM8+reLM9)/
  (reLM13+reLM14+reLM15)/(reLM19+reLM20+reLM21)/(reLM25+reLM26+reLM27)
dev.off()

pdf(file="resid_LM2.pdf",width=10,height=7)
(reLM31+reLM32+reLM33)/(reLM34+reLM35+reLM36)/(reLM37+reLM38+reLM39)
dev.off()

pdf(file="resid_LM3.pdf",width=11,height=11)
(reLM10+reLM11+reLM12)/(reLM16+reLM17+reLM18)/
  (reLM22+reLM23+reLM24)/(reLM28+reLM28+reLM30)
dev.off()


# ------------------------------------------------------ #
#2# SEM for MV_PE
# From Theory and Experiments: MV_PE may be affected by all variables
# (the four community metrics, environment and human impacts). Z-value may be
# affected by synchrony (see Fig. S12f in Anderson et al.) and richness
# (see Fig. S12e in Anderson et al.). Synchrony may be affected by evenness
# (see Fig. 5 in Anderson et al.) and richness (theoretical).
# Finally, evenness may be related to z and richness.

#2.1# Plot distribution of MV_PE, AvCV_PE, Syn and z-value

names(portfolio)

pt1<-ggplot(data=portfolio,aes(x=z,xmin=z-ci_z,xmax=z+ci_z,y=plotOrd))+
  geom_point(aes(col=Region),size=2.5)+
  geom_pointrange(aes(col=Region),position=position_dodge(width=0.25))+
  geom_vline(xintercept=2)+
  scale_x_continuous("Taylor's power law z-value")+
  scale_y_continuous("",breaks=seq(1,54,1),labels=portfolio$System)+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",axis.text.y=element_text(size=8),
        axis.text.x=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

pt2<-ggplot(data=portfolio,aes(x=syn,y=plotOrd))+
  geom_point(aes(col=Region),size=2.5)+
  scale_x_continuous("Synchrony")+
  scale_y_continuous("",breaks=seq(1,54,1),labels=portfolio$System)+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",axis.text.y=element_blank(),
        axis.text.x=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

pt3<-ggplot(data=portfolio,aes(x=AvCV_PE,xmin=ci1_AvCV_PE,xmax=ci2_AvCV_PE,y=plotOrd))+
  geom_point(aes(col=Region),size=2.5)+
  geom_pointrange(aes(col=Region),position=position_dodge(width=0.25))+
  geom_vline(xintercept=1)+
  scale_x_continuous(breaks=c(1,2,3,4,5,6),"Portfolio Effect (CVPE)")+
  scale_y_continuous("",breaks=seq(1,54,1),labels=portfolio$System)+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",axis.text.y=element_text(size=8),
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

pt4<-ggplot(data=portfolio,aes(x=MV_PE,xmin=ci1_MV_PE,xmax=ci2_MV_PE,y=plotOrd))+
  geom_point(aes(col=Region),size=2.5)+
  geom_pointrange(aes(col=Region),position=position_dodge(width=0.25))+
  geom_vline(xintercept=1)+
  scale_x_continuous("Portfolio Effect (MVPE)")+
  scale_y_continuous("",breaks=seq(1,54,1),labels=portfolio$System)+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",axis.text.y=element_blank(),
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

pdf(file="PEandZ_values.pdf",width=13,height=15)
(pt1+pt2)/(pt3+pt4)
dev.off()

#2.2# Standardize variables and fit SEM

portfolio$MV_PE<-MyStd(portfolio$MV_PE)
portfolio$AvCV_PE<-MyStd(portfolio$AvCV_PE)
portfolio$z<-MyStd(portfolio$z)
portfolio$syn<-MyStd(portfolio$syn)
portfolio$even<-MyStd(portfolio$even)
portfolio$rich<-MyStd(portfolio$rich)
portfolio$Depth<-MyStd(portfolio$Depth)
portfolio$DepthCV<-MyStd(portfolio$DepthCV)
portfolio$Chla<-MyStd(portfolio$Chla)
portfolio$ChlaCV<-MyStd(portfolio$ChlaCV)
portfolio$SBT<-MyStd(portfolio$SBT)
portfolio$SBTrange<-MyStd(portfolio$SBTrange)
portfolio$TAI<-MyStd(portfolio$TAI)
portfolio$Trawl<-MyStd(portfolio$Trawl)

#2.2.1# Fit SEM using lavaan

peSEM.mv<-'MV_PE ~ rich + z + syn + even + DepthCV
           z     ~ rich + Depth + SBT
           syn   ~ even + ChlaCV + TAI
           even  ~ DepthCV + Chla + SBTrange + Trawl
           rich  ~ ChlaCV + DepthCV'

defSEM<-sem(peSEM.mv,data=portfolio)
summary(defSEM,rsquare=T,standardized=T)
lavaanPlot(model=defSEM,coefs=T,stand=T,graph_options=list(layout="circo"),sig=0.05)

#2.2.2# Fit SEM using picewiseSEM

psemMVPE1<-lm(MV_PE ~ rich + z + syn + even + DepthCV,data=portfolio)
psemMVPE2<-lm(z     ~ rich + Depth + SBT,data=portfolio)
psemMVPE3<-lm(syn   ~ even + ChlaCV + TAI,data=portfolio)
psemMVPE4<-lm(even  ~ DepthCV + Chla + SBTrange + Trawl,data=portfolio)
psemMVPE5<-lm(rich  ~ ChlaCV + DepthCV,data=portfolio)

psemMVPE.def<-psem(psemMVPE1,psemMVPE2,psemMVPE3,psemMVPE4,psemMVPE5)

coefs(psemMVPE.def,standardize="scale")
rsquared(psemMVPE.def)
dSep(psemMVPE.def)
fisherC(psemMVPE.def)
plot(psemMVPE.def)

vif(psemMVPE1);vif(psemMVPE2);vif(psemMVPE3);vif(psemMVPE4);vif(psemMVPE5)

#2.3# Calculating direct and indirect effects for MV_PE using lavaan syntax

#2.3.1# Calculation within the model formulation

modelEffMVPE<-'MV_PE ~ mr*rich + mz*z + ms*syn + me*even + md*DepthCV
               z     ~ zr*rich + zd*Depth + zs*SBT
               syn   ~ se*even + sc*ChlaCV + st*TAI 
               even  ~ ed*DepthCV + ec*Chla + es*SBTrange + et*Trawl
               rich  ~ rc*ChlaCV + rd*DepthCV
           
               directRich       := mr
               directZ          := mz
               directSyn        := ms
               directEven       := me
               directDepthCV    := md
               
               indirectRich     := zr*mz
               indirectEven     := se*ms
               
               indirectChla     := ec*me + (ec*se*ms)
               indirectChlaCV   := (sc*ms) + (rc*mr) + (rc*zr*mz)
               
               indirectSBT      := zs*mz
               indirectSBTrange := es*me + (es*se*ms)
               
               indirectDepth    := zd*mz
               indirectDepthCV  := (ed*me) + (ed*se*ms) + (rd*mr) + (rd*zr*mz)
               
               indirectTAI      := st*ms
               indirectTrawl    := (et*me) + (et*se*ms)
               
               totalRich        := directRich + indirectRich
               totalZ           := directZ
               totalSyn         := directSyn
               totalEven        := directEven + indirectEven
               totalDepth       := indirectDepth
               totalDepthCV     := directDepthCV + indirectDepthCV
               totalChla        := indirectChla
               totalChlaCV      := indirectChlaCV
               totalSBT         := indirectSBT
               totalSBTrange    := indirectSBTrange
               totalTAI         := indirectTAI
               totalTrawl       := indirectTrawl'

partial.defSEM.MVPEeffects<-sem(modelEffMVPE,data=portfolio)
summary(partial.defSEM.MVPEeffects,standardized=T)

#2.3.2# Plot direct and indirect effects

sem.MVPEeffects<-data.frame(summary(partial.defSEM.MVPEeffects,standardized=T)$pe[59:85,])

sem.MVPEeffects$varName<-c("Richness","z-value","Synchrony","Evenness","DepthCV",
                           "Richness","Evenness","Chla","ChlaCV","SBT","SBTrange",
                           "Depth","DepthCV","TAI","Trawl","Richness","z-value",
                           "Synchrony","Evenness","Depth","DepthCV","Chla","ChlaCV",
                           "SBT","SBTrange","TAI","Trawl")

sem.MVPEeffects$effType<-c("Direct","Direct","Direct","Direct","Direct",
                           "Indirect","Indirect","Indirect","Indirect","Indirect",
                           "Indirect","Indirect","Indirect","Indirect","Indirect",
                           "Total","Total","Total","Total","Total","Total",
                           "Total","Total","Total","Total","Total","Total")

sem.MVPEeffects$varNum<-factor(c(1,2,3,4,6,1,4,7,8,9,10,5,6,11,12,
                                 1,2,3,4,5,6,7,8,9,10,11,12))

pdf(file="MVPE_SEM_dir_indir.pdf")
ggplot(data=filter(sem.MVPEeffects,effType != "Total"),
       aes(y=varNum,x=std.all))+
  geom_col(aes(fill=effType))+
  geom_point(data=filter(sem.MVPEeffects,effType == "Total"),
             aes(y=varNum,x=std.all))+
  scale_y_discrete("",labels=c("1"="Richness","2"="z-value","3"="Synchrony",
                               "4"="Evenness","5"="Depth","6"="DepthCV",
                               "7"="Chla","8"="ChlaCV","9"="SBT",
                               "10"="SBTrange","11"="TAI","12"="Trawl"))+
  scale_x_continuous("Standardized effect on MVPE",
                     breaks=c(-0.8,-0.6,-0.4,-0.2,0,0.2,0.4,0.6),limits=c(-0.85,0.45))+
  scale_fill_manual("",values=c("#E7B800","#00AFBB"))+
  geom_vline(xintercept=0,linetype="dashed")+
  theme_classic()+
  background_grid()+
  theme(legend.position=c(0,1),legend.justification=c(-0.4,1.2),
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")
dev.off()

#2.4# Residuals for each model included in the psem

portfolio$residMVPE1<-residuals(psemMVPE1) # MVPE model
portfolio$residMVPE2<-residuals(psemMVPE2) # z-value model
portfolio$residMVPE3<-residuals(psemMVPE3) # Synchrony model
portfolio$residMVPE4<-residuals(psemMVPE4) # Evenness model
portfolio$residMVPE5<-residuals(psemMVPE5) # Richness model

portfolio$fitMVPE1<-fitted(psemMVPE1)
portfolio$fitMVPE2<-fitted(psemMVPE2)
portfolio$fitMVPE3<-fitted(psemMVPE3)
portfolio$fitMVPE4<-fitted(psemMVPE4)
portfolio$fitMVPE5<-fitted(psemMVPE5)

reMVPE1<-ggplot(data=portfolio,aes(x=fitMVPE1,y=residMVPE1))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

reMVPE2<-ggplot(data=portfolio,aes(x=residMVPE1))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

reMVPE3<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residMVPE1),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

reMVPE4<-ggplot(data=portfolio,aes(x=fitMVPE2,y=residMVPE2))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

reMVPE5<-ggplot(data=portfolio,aes(x=residMVPE2))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

reMVPE6<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residMVPE2),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

reMVPE7<-ggplot(data=portfolio,aes(x=fitMVPE3,y=residMVPE3))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

reMVPE8<-ggplot(data=portfolio,aes(x=residMVPE3))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

reMVPE9<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residMVPE3),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

reMVPE10<-ggplot(data=portfolio,aes(x=fitMVPE4,y=residMVPE4))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(J)")

reMVPE11<-ggplot(data=portfolio,aes(x=residMVPE4))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(K)")

reMVPE12<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residMVPE4),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(L)")

reMVPE13<-ggplot(data=portfolio,aes(x=fitMVPE5,y=residMVPE5))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="Fitted")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(M)")

reMVPE14<-ggplot(data=portfolio,aes(x=residMVPE5))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="Residuals")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(N)")

reMVPE15<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residMVPE5),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="Longitude (ºW-E)")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(O)")

pdf(file="resids_MVPE.pdf",width=12,height=15)
(reMVPE1+reMVPE2+reMVPE3)/(reMVPE4+reMVPE5+reMVPE6)/
  (reMVPE7+reMVPE8+reMVPE9)/(reMVPE10+reMVPE11+reMVPE12)/
  (reMVPE13+reMVPE14+reMVPE15)
dev.off()

#2.5# Partial plots for MV_PE SEM

coef(defSEM)

#2.5.1# Partial richness effect on MV_PE

portfolio$MV_PEpart_rich<- portfolio$MV_PE -
  (coef(defSEM)[2]*portfolio$z) -
  (coef(defSEM)[3]*portfolio$syn) -
  (coef(defSEM)[4]*portfolio$even) -
  (coef(defSEM)[5]*portfolio$DepthCV)

x.line.pe.rich<-seq(from=min(portfolio$rich),to=max(portfolio$rich),by=0.1)
y.line.pe.rich<- coef(defSEM)[1]*x.line.pe.rich
line.pe.rich<-as.data.frame(cbind(x.line.pe.rich,y.line.pe.rich))

#2.5.2# Partial z-value effect on MV_PE

portfolio$MV_PEpart_z<- portfolio$MV_PE -
  (coef(defSEM)[1]*portfolio$rich) -
  (coef(defSEM)[3]*portfolio$syn) -
  (coef(defSEM)[4]*portfolio$even) -
  (coef(defSEM)[5]*portfolio$DepthCV)

x.line.pe.z<-seq(from=min(portfolio$z),to=max(portfolio$z),by=0.1)
y.line.pe.z<- coef(defSEM)[2]*x.line.pe.z
line.pe.z<-as.data.frame(cbind(x.line.pe.z,y.line.pe.z))

#2.5.3# Partial synchrony effect on MV_PE

portfolio$MV_PEpart_syn<- portfolio$MV_PE -
  (coef(defSEM)[1]*portfolio$rich) -
  (coef(defSEM)[2]*portfolio$z) -
  (coef(defSEM)[4]*portfolio$even) -
  (coef(defSEM)[5]*portfolio$DepthCV)

x.line.pe.syn<-seq(from=min(portfolio$syn),to=max(portfolio$syn),by=0.1)
y.line.pe.syn<- coef(defSEM)[3]*x.line.pe.syn
line.pe.syn<-as.data.frame(cbind(x.line.pe.syn,y.line.pe.syn))

#2.5.4# Partial evenness effect on MV_PE

portfolio$MV_PEpart_even<- portfolio$MV_PE -
  (coef(defSEM)[1]*portfolio$rich) -
  (coef(defSEM)[2]*portfolio$z) -
  (coef(defSEM)[3]*portfolio$syn) -
  (coef(defSEM)[5]*portfolio$DepthCV)

x.line.pe.even<-seq(from=min(portfolio$even),to=max(portfolio$even),by=0.1)
y.line.pe.even<-coef(defSEM)[4]*x.line.pe.even
line.pe.even<-as.data.frame(cbind(x.line.pe.even,y.line.pe.even))

#2.5.5# Partial DepthCV effect on MV_PE

portfolio$MV_PEpart_depthCV<- portfolio$MV_PE -
  (coef(defSEM)[1]*portfolio$rich) -
  (coef(defSEM)[2]*portfolio$z) -
  (coef(defSEM)[3]*portfolio$syn) -
  (coef(defSEM)[4]*portfolio$even)

x.line.pe.depth<-seq(from=min(portfolio$DepthCV),to=max(portfolio$DepthCV),by=0.1)
y.line.pe.depth<-coef(defSEM)[5]*x.line.pe.depth
line.pe.depth<-as.data.frame(cbind(x.line.pe.depth,y.line.pe.depth))

#2.5.6# Partial richness effect on z-value

portfolio$Zpart_rich<- portfolio$z -
  (coef(defSEM)[7]*portfolio$Depth) -
  (coef(defSEM)[8]*portfolio$SBT)

x.line.z.rich<-seq(from=min(portfolio$rich),to=max(portfolio$rich),by=0.1)
y.line.z.rich<-coef(defSEM)[6]*x.line.z.rich
line.z.rich<-as.data.frame(cbind(x.line.z.rich,y.line.z.rich))

#2.5.7# Partial Depth effect on z-value

portfolio$Zpart_depth<- portfolio$z -
  (coef(defSEM)[6]*portfolio$rich) -
  (coef(defSEM)[8]*portfolio$SBT)

x.line.z.depth<-seq(from=min(portfolio$Depth),to=max(portfolio$Depth),by=0.1)
y.line.z.depth<-coef(defSEM)[7]*x.line.z.depth
line.z.depth<-as.data.frame(cbind(x.line.z.depth,y.line.z.depth))

#2.5.8# Partial SBT effect on z-value

portfolio$Zpart_sbt<- portfolio$z -
  (coef(defSEM)[6]*portfolio$rich) -
  (coef(defSEM)[7]*portfolio$Depth)

x.line.z.sbt<-seq(from=min(portfolio$SBT),to=max(portfolio$SBT),by=0.1)
y.line.z.sbt<-coef(defSEM)[8]*x.line.z.sbt
line.z.sbt<-as.data.frame(cbind(x.line.z.sbt,y.line.z.sbt))

#2.5.9# Partial evenness effect on synchrony

portfolio$SYNpart_even<- portfolio$syn -
  (coef(defSEM)[10]*portfolio$ChlaCV) -
  (coef(defSEM)[11]*portfolio$TAI)

x.line.syn.even<-seq(from=min(portfolio$even),to=max(portfolio$even),by=0.1)
y.line.syn.even<-coef(defSEM)[9]*x.line.syn.even
line.syn.even<-as.data.frame(cbind(x.line.syn.even,y.line.syn.even))

#2.5.10# Partial ChlaCV effect on synchrony

portfolio$SYNpart_chla<- portfolio$syn -
  (coef(defSEM)[9]*portfolio$even) -
  (coef(defSEM)[11]*portfolio$TAI)

x.line.syn.chla<-seq(from=min(portfolio$ChlaCV),to=max(portfolio$ChlaCV),by=0.1)
y.line.syn.chla<-coef(defSEM)[10]*x.line.syn.chla
line.syn.chla<-as.data.frame(cbind(x.line.syn.chla,y.line.syn.chla))

#2.5.11# Partial TAI effect on synchrony

portfolio$SYNpart_tai<- portfolio$syn -
  (coef(defSEM)[9]*portfolio$even) -
  (coef(defSEM)[10]*portfolio$ChlaCV)

x.line.syn.tai<-seq(from=min(portfolio$TAI),to=max(portfolio$TAI),by=0.1)
y.line.syn.tai<-coef(defSEM)[11]*x.line.syn.tai
line.syn.tai<-as.data.frame(cbind(x.line.syn.tai,y.line.syn.tai))

#2.5.12# Partial DepthCV effect on evenness

portfolio$EVENpart_depth<- portfolio$even -
  (coef(defSEM)[13]*portfolio$Chla) -
  (coef(defSEM)[14]*portfolio$SBTrange) -
  (coef(defSEM)[15]*portfolio$Trawl)

x.line.even.depth<-seq(from=min(portfolio$DepthCV),to=max(portfolio$DepthCV),by=0.1)
y.line.even.depth<-coef(defSEM)[12]*x.line.even.depth
line.even.depth<-as.data.frame(cbind(x.line.even.depth,y.line.even.depth))

#2.5.13# Partial Chla effect on evenness

portfolio$EVENpart_chla<- portfolio$even -
  (coef(defSEM)[12]*portfolio$DepthCV) -
  (coef(defSEM)[14]*portfolio$SBTrange) -
  (coef(defSEM)[15]*portfolio$Trawl)

x.line.even.chla<-seq(from=min(portfolio$Chla),to=max(portfolio$Chla),by=0.1)
y.line.even.chla<-coef(defSEM)[13]*x.line.even.chla
line.even.chla<-as.data.frame(cbind(x.line.even.chla,y.line.even.chla))

#2.5.14# Partial SBTrange effect on evenness

portfolio$EVENpart_sbt<- portfolio$even -
  (coef(defSEM)[12]*portfolio$DepthCV) -
  (coef(defSEM)[13]*portfolio$Chla) -
  (coef(defSEM)[15]*portfolio$Trawl)

x.line.even.sbt<-seq(from=min(portfolio$SBTrange),to=max(portfolio$SBTrange),by=0.1)
y.line.even.sbt<-coef(defSEM)[14]*x.line.even.sbt
line.even.sbt<-as.data.frame(cbind(x.line.even.sbt,y.line.even.sbt))

#2.5.15# Partial Trawl effect on evenness

portfolio$EVENpart_trawl<- portfolio$even -
  (coef(defSEM)[12]*portfolio$DepthCV) -
  (coef(defSEM)[13]*portfolio$Chla) -
  (coef(defSEM)[14]*portfolio$SBTrange)

x.line.even.trawl<-seq(from=min(portfolio$Trawl),to=max(portfolio$Trawl),by=0.1)
y.line.even.trawl<-coef(defSEM)[15]*x.line.even.trawl
line.even.trawl<-as.data.frame(cbind(x.line.even.trawl,y.line.even.trawl))

#2.5.16# Partial ChlaCV effect on richness

portfolio$RICHpart_chla<- portfolio$rich -
  (coef(defSEM)[17]*portfolio$DepthCV)

x.line.rich.chla<-seq(from=min(portfolio$ChlaCV),to=max(portfolio$ChlaCV),by=0.1)
y.line.rich.chla<-coef(defSEM)[16]*x.line.rich.chla
line.rich.chla<-as.data.frame(cbind(x.line.rich.chla,y.line.rich.chla))

#2.5.17# Partial DepthCV effect on richness

portfolio$RICHpart_depth<- portfolio$rich -
  (coef(defSEM)[16]*portfolio$ChlaCV)

x.line.rich.depth<-seq(from=min(portfolio$DepthCV),to=max(portfolio$DepthCV),by=0.1)
y.line.rich.depth<-coef(defSEM)[17]*x.line.rich.depth
line.rich.depth<-as.data.frame(cbind(x.line.rich.depth,y.line.rich.depth))

#2.5.18# All partial effects plots together

names(portfolio)

pe1<-ggplot()+
  geom_point(data=portfolio,aes(y=MV_PEpart_rich,x=rich,col=Region))+
  geom_line(data=line.pe.rich,aes(x=x.line.pe.rich,y=y.line.pe.rich),linewidth=1,col="gray50")+
  labs(y="MVPE",x="Richness")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

pe2<-ggplot()+
  geom_point(data=portfolio,aes(y=MV_PEpart_z,x=z,col=Region))+
  geom_line(data=line.pe.z,aes(x=x.line.pe.z,y=y.line.pe.z),linewidth=1,col="gray50",
            linetype="dashed")+
  labs(y="",x="z-value")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

pe3<-ggplot()+
  geom_point(data=portfolio,aes(y=MV_PEpart_syn,x=syn,col=Region))+
  geom_line(data=line.pe.syn,aes(x=x.line.pe.syn,y=y.line.pe.syn),linewidth=1,col="gray50")+
  labs(y="",x="Synchrony")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

pe4<-ggplot()+
  geom_point(data=portfolio,aes(y=MV_PEpart_even,x=even,col=Region))+
  geom_line(data=line.pe.even,aes(x=x.line.pe.even,y=y.line.pe.even),linewidth=1,col="gray50")+
  labs(y="",x="Evenness")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

pe5<-ggplot()+
  geom_point(data=portfolio,aes(y=MV_PEpart_depthCV,x=DepthCV,col=Region))+
  geom_line(data=line.pe.depth,aes(x=x.line.pe.depth,y=y.line.pe.depth),linewidth=1,col="gray50")+
  labs(y="",x="DepthCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

pe6<-ggplot()+
  geom_point(data=portfolio,aes(y=Zpart_rich,x=rich,col=Region))+
  geom_line(data=line.z.rich,aes(x=x.line.z.rich,y=y.line.z.rich),linewidth=1,col="gray50")+
  labs(y="z-value",x="Richness")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

pe7<-ggplot()+
  geom_point(data=portfolio,aes(y=Zpart_depth,x=Depth,col=Region))+
  geom_line(data=line.z.depth,aes(x=x.line.z.depth,y=y.line.z.depth),linewidth=1,col="gray50")+
  labs(y="",x="Depth")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

pe8<-ggplot()+
  geom_point(data=portfolio,aes(y=Zpart_sbt,x=SBT,col=Region))+
  geom_line(data=line.z.sbt,aes(x=x.line.z.sbt,y=y.line.z.sbt),linewidth=1,col="gray50")+
  labs(y="",x="SBT")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

pe9<-ggplot()+
  geom_point(data=portfolio,aes(y=SYNpart_even,x=even,col=Region))+
  geom_line(data=line.syn.even,aes(x=x.line.syn.even,y=y.line.syn.even),linewidth=1,col="gray50")+
  labs(y="Synchrony",x="Evenness")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

pe10<-ggplot()+
  geom_point(data=portfolio,aes(y=SYNpart_tai,x=TAI,col=Region))+
  geom_line(data=line.syn.tai,aes(x=x.line.syn.tai,y=y.line.syn.tai),linewidth=1,col="gray50")+
  labs(y="",x="TAI")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(J)")

pe11<-ggplot()+
  geom_point(data=portfolio,aes(y=SYNpart_chla,x=ChlaCV,col=Region))+
  geom_line(data=line.syn.chla,aes(x=x.line.syn.chla,y=y.line.syn.chla),linewidth=1,col="gray50")+
  labs(y="",x="ChlaCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(K)")

pe12<-ggplot()+
  geom_point(data=portfolio,aes(y=EVENpart_depth,x=DepthCV,col=Region))+
  geom_line(data=line.even.depth,aes(x=x.line.even.depth,y=y.line.even.depth),linewidth=1,col="gray50")+
  labs(y="Evenness",x="DepthCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(L)")

pe13<-ggplot()+
  geom_point(data=portfolio,aes(y=EVENpart_chla,x=Chla,col=Region))+
  geom_line(data=line.even.chla,aes(x=x.line.even.chla,y=y.line.even.chla),linewidth=1,col="gray50")+
  labs(y="",x="Chla")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(M)")

pe14<-ggplot()+
  geom_point(data=portfolio,aes(y=EVENpart_sbt,x=SBTrange,col=Region))+
  geom_line(data=line.even.sbt,aes(x=x.line.even.sbt,y=y.line.even.sbt),linewidth=1,col="gray50")+
  labs(y="",x="SBTrange")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(N)")

pe15<-ggplot()+
  geom_point(data=portfolio,aes(y=EVENpart_trawl,x=Trawl,col=Region))+
  geom_line(data=line.even.trawl,aes(x=x.line.even.trawl,y=y.line.even.trawl),linewidth=1,col="gray50")+
  labs(y="",x="Trawl")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(O)")

pe16<-ggplot()+
  geom_point(data=portfolio,aes(y=RICHpart_chla,x=ChlaCV,col=Region))+
  geom_line(data=line.rich.chla,aes(x=x.line.rich.chla,y=y.line.rich.chla),linewidth=1,col="gray50")+
  labs(y="Richness",x="ChlaCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(P)")

pe17<-ggplot()+
  geom_point(data=portfolio,aes(y=RICHpart_depth,x=DepthCV,col=Region))+
  geom_line(data=line.rich.depth,aes(x=x.line.rich.depth,y=y.line.rich.depth),linewidth=1,col="gray50")+
  labs(y="",x="DepthCV")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(Q)")

pdf(file="MVPE_SEM_partial_plots.pdf",width=13,height=11)
pe1+pe2+pe3+pe4+pe5+
  pe6+pe7+pe8+plot_spacer()+plot_spacer()+
  pe9+pe10+pe11+plot_spacer()+plot_spacer()+
  pe12+pe13+pe14+pe15+plot_spacer()+
  pe16+pe17+plot_spacer()+plot_spacer()+plot_spacer()+plot_layout(ncol=5)
dev.off()


# ------------------------------------------------------ #
#3# SEM for AvCV_PE using lavaan

#3.1# Same model structure as for MV_PE

peSEMCV<-'AvCV_PE ~ rich + z + syn + even + DepthCV
          z       ~ rich + Depth + SBT
          syn     ~ even + ChlaCV + TAI
          even    ~ DepthCV + Chla + SBTrange + Trawl
          rich    ~ ChlaCV + DepthCV'

partial.peSEMCV<-sem(peSEMCV,data=portfolio)
summary(partial.peSEMCV,rsquare=T,standardized=T)
lavaanPlot(model=partial.peSEMCV,coefs=T,stand=T,graph_options=list(layout="circo"),sig=0.05)

#3.2# Calculating direct and indirect effects for AvCV_PE using lavaan syntax

#3.2.1# Calculation within the model formulation

modelEffCVPE<-'AvCV_PE ~ mr*rich + mz*z + ms*syn + me*even + md*DepthCV
               z     ~ zr*rich + zd*Depth + zs*SBT
               syn   ~ se*even + sc*ChlaCV + st*TAI 
               even  ~ ed*DepthCV + ec*Chla + es*SBTrange + et*Trawl
               rich  ~ rc*ChlaCV + rd*DepthCV
           
               directRich       := mr
               directZ          := mz
               directSyn        := ms
               directEven       := me
               directDepthCV    := md
               
               indirectRich     := zr*mz
               indirectEven     := se*ms
               
               indirectChla     := ec*me + (ec*se*ms)
               indirectChlaCV   := (sc*ms) + (rc*mr) + (rc*zr*mz)
               
               indirectSBT      := zs*mz
               indirectSBTrange := es*me + (es*se*ms)
               
               indirectDepth    := zd*mz
               indirectDepthCV  := (ed*me) + (ed*se*ms) + (rd*mr) + (rd*zr*mz)
               
               indirectTAI      := st*ms
               indirectTrawl    := (et*me) + (et*se*ms)
               
               totalRich        := directRich + indirectRich
               totalZ           := directZ
               totalSyn         := directSyn
               totalEven        := directEven + indirectEven
               totalDepth       := indirectDepth
               totalDepthCV     := directDepthCV + indirectDepthCV
               totalChla        := indirectChla
               totalChlaCV      := indirectChlaCV
               totalSBT         := indirectSBT
               totalSBTrange    := indirectSBTrange
               totalTAI         := indirectTAI
               totalTrawl       := indirectTrawl'

partial.defSEM.CVPEeffects<-sem(modelEffCVPE,data=portfolio)
summary(partial.defSEM.CVPEeffects,standardized=T)

#3.2.2# Plot direct and indirect effects

sem.CVPEeffects<-data.frame(summary(partial.defSEM.CVPEeffects,standardized=T)$pe[59:85,])

sem.CVPEeffects$varName<-c("Richness","z-value","Synchrony","Evenness","DepthCV",
                           "Richness","Evenness","Chla","ChlaCV","SBT","SBTrange",
                           "Depth","DepthCV","TAI","Trawl","Richness","z-value",
                           "Synchrony","Evenness","Depth","DepthCV","Chla","ChlaCV",
                           "SBT","SBTrange","TAI","Trawl")

sem.CVPEeffects$effType<-c("Direct","Direct","Direct","Direct","Direct",
                           "Indirect","Indirect","Indirect","Indirect","Indirect",
                           "Indirect","Indirect","Indirect","Indirect","Indirect",
                           "Total","Total","Total","Total","Total","Total",
                           "Total","Total","Total","Total","Total","Total")

sem.CVPEeffects$varNum<-factor(c(1,2,3,4,6,1,4,7,8,9,10,5,6,11,12,
                                 1,2,3,4,5,6,7,8,9,10,11,12))

pdf(file="CVPE_SEM_dir_indir.pdf")
ggplot(data=filter(sem.CVPEeffects,effType != "Total"),
       aes(y=varNum,x=std.all))+
  geom_col(aes(fill=effType))+
  geom_point(data=filter(sem.CVPEeffects,effType == "Total"),
             aes(y=varNum,x=std.all))+
  scale_y_discrete("",labels=c("1"="Richness","2"="z-value","3"="Synchrony",
                               "4"="Evenness","5"="Depth","6"="DepthCV",
                               "7"="Chla","8"="ChlaCV","9"="SBT",
                               "10"="SBTrange","11"="TAI","12"="Trawl"))+
  scale_x_continuous("Standardized effect on CVPE",
                     breaks=c(-0.8,-0.6,-0.4,-0.2,0,0.2,0.4,0.6),limits=c(-0.85,0.45))+
  scale_fill_manual("",values=c("#E7B800","#00AFBB"))+
  geom_vline(xintercept=0,linetype="dashed")+
  theme_classic()+
  background_grid()+
  theme(legend.position=c(0,1),legend.justification=c(-0.4,1.2),
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")
dev.off()

#3.3# SEM with picewiseSEM for AvCV_PE

psemCVPE1<-lm(AvCV_PE ~ rich + z + syn + even + DepthCV,data=portfolio)
psemCVPE2<-lm(z       ~ rich + Depth + SBT,data=portfolio)
psemCVPE3<-lm(syn     ~ even + ChlaCV + TAI,data=portfolio)
psemCVPE4<-lm(even    ~ DepthCV + Chla + SBTrange + Trawl,data=portfolio)
psemCVPE5<-lm(rich    ~ ChlaCV + DepthCV,data=portfolio)

psemCVPE.def<-psem(psemCVPE1,psemCVPE2,psemCVPE3,psemCVPE4,psemCVPE5)

coefs(psemCVPE.def,standardize="scale")
rsquared(psemCVPE.def)
dSep(psemCVPE.def)
fisherC(psemCVPE.def)
plot(psemCVPE.def)

vif(psemCVPE1);vif(psemCVPE2);vif(psemCVPE3);vif(psemCVPE4);vif(psemCVPE5)

#3.4# Residuals for each model included in the psem

portfolio$residCVPE1<-residuals(psemCVPE1) # CVPE model
portfolio$residCVPE2<-residuals(psemCVPE2) # z-value model
portfolio$residCVPE3<-residuals(psemCVPE3) # Synchrony model
portfolio$residCVPE4<-residuals(psemCVPE4) # Evenness model
portfolio$residCVPE5<-residuals(psemCVPE5) # Richness model

portfolio$fitCVPE1<-fitted(psemCVPE1)
portfolio$fitCVPE2<-fitted(psemCVPE2)
portfolio$fitCVPE3<-fitted(psemCVPE3)
portfolio$fitCVPE4<-fitted(psemCVPE4)
portfolio$fitCVPE5<-fitted(psemCVPE5)

reCVPE1<-ggplot(data=portfolio,aes(x=fitCVPE1,y=residCVPE1))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

reCVPE2<-ggplot(data=portfolio,aes(x=residCVPE1))+
  geom_histogram(binwidth=0.2)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

reCVPE3<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residCVPE1),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

reCVPE4<-ggplot(data=portfolio,aes(x=fitCVPE2,y=residCVPE2))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

reCVPE5<-ggplot(data=portfolio,aes(x=residCVPE2))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

reCVPE6<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residCVPE2),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

reCVPE7<-ggplot(data=portfolio,aes(x=fitCVPE3,y=residCVPE3))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

reCVPE8<-ggplot(data=portfolio,aes(x=residCVPE3))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

reCVPE9<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residCVPE3),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

reCVPE10<-ggplot(data=portfolio,aes(x=fitCVPE4,y=residCVPE4))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(J)")

reCVPE11<-ggplot(data=portfolio,aes(x=residCVPE4))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(K)")

reCVPE12<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residCVPE4),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(L)")

reCVPE13<-ggplot(data=portfolio,aes(x=fitCVPE5,y=residCVPE5))+
  geom_point(alpha=0.4,size=4)+
  geom_hline(yintercept=0)+
  labs(y="Residuals",x="Fitted")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(M)")

reCVPE14<-ggplot(data=portfolio,aes(x=residCVPE5))+
  geom_histogram(binwidth=0.4)+
  labs(y="Count",x="Residuals")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(N)")

reCVPE15<-ggplot(data=portfolio,aes(x=Longitude,y=Latitude))+
  geom_polygon(data=m.world,aes(x=long,y=lat,group=group),
               fill="gray80",col="white")+
  coord_cartesian(xlim=c(-95,35),ylim=c(10,70))+
  geom_point(aes(col=residCVPE5),size=2)+
  scale_colour_gradient2("Residuals",low=("blue"),
                         mid=("white"),high=("red"),midpoint=0)+
  labs(y="Latitude (ºN)",x="Longitude (ºW-E)")+
  theme_classic()+
  background_grid()+
  theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(O)")

pdf(file="resids_CVPE.pdf",width=12,height=15)
(reCVPE1+reCVPE2+reCVPE3)/(reCVPE4+reCVPE5+reCVPE6)/
  (reCVPE7+reCVPE8+reCVPE9)/(reCVPE10+reCVPE11+reCVPE12)/
  (reCVPE13+reCVPE14+reCVPE15)
dev.off()


# ------------------------------------------------------ #
#4# Check if community composition based on the CWMs
# influences somehow the partial relationships from the MV_PE SEM

#4.1# Establish CWM categories (below and above the mean value for each CWM)

names(portfolio)

par(mfrow=c(1,3))
hist(portfolio$K);abline(v=mean(portfolio$K,na.rm=T),col=2,lty="dashed")
hist(portfolio$L50);abline(v=mean(portfolio$L50,na.rm=T),col=2,lty="dashed")
hist(portfolio$TL);abline(v=mean(portfolio$TL,na.rm=T),col=2,lty="dashed")

portfolio$Kgroup<-factor(ifelse(portfolio$K < mean(portfolio$K,na.rm=T),"Slow K","Fast K"))
portfolio$L50group<-factor(ifelse(portfolio$L50 < mean(portfolio$L50,na.rm=T),"Early maturity","Late maturity"))
portfolio$TLgroup<-factor(ifelse(portfolio$TL < mean(portfolio$TL,na.rm=T),"Low TL","High TL"))

#4.2# Univariate relationships for MV_PE partial effects

i1<-ggplot(data=portfolio,aes(y=MV_PEpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="MVPE",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

i2<-ggplot(data=portfolio,aes(y=MV_PEpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

i3<-ggplot(data=portfolio,aes(y=MV_PEpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

i4<-ggplot(data=portfolio,aes(y=MV_PEpart_z,x=z))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup),linetype="dashed")+
  facet_wrap(~Kgroup)+
  labs(y="MVPE",x="z-value")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

i5<-ggplot(data=portfolio,aes(y=MV_PEpart_z,x=z))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group),linetype="dashed")+
  facet_wrap(~L50group)+
  labs(y="",x="z-value")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

i6<-ggplot(data=portfolio,aes(y=MV_PEpart_z,x=z))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup),linetype="dashed")+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="z-value")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

i7<-ggplot(data=portfolio,aes(y=MV_PEpart_syn,x=syn))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="MVPE",x="Synchrony")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

i8<-ggplot(data=portfolio,aes(y=MV_PEpart_syn,x=syn))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Synchrony")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

i9<-ggplot(data=portfolio,aes(y=MV_PEpart_syn,x=syn))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Synchrony")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

i10<-ggplot(data=portfolio,aes(y=MV_PEpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="MVPE",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(J)")

i11<-ggplot(data=portfolio,aes(y=MV_PEpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(K)")

i12<-ggplot(data=portfolio,aes(y=MV_PEpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(L)")

i13<-ggplot(data=portfolio,aes(y=MV_PEpart_depthCV,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="MVPE",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(M)")

i14<-ggplot(data=portfolio,aes(y=MV_PEpart_depthCV,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(N)")

i15<-ggplot(data=portfolio,aes(y=MV_PEpart_depthCV,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(O)")

pdf(file="MVPE_cwm_int.pdf",width=10,height=12)
(i1+i2+i3)/(i4+i5+i6)/(i7+i8+i9)/(i10+i11+i12)/(i13+i14+i15)
dev.off()

#4.3# Univariate relationships for Z-value partial effects

i16<-ggplot(data=portfolio,aes(y=Zpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="z-value",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

i17<-ggplot(data=portfolio,aes(y=Zpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

i18<-ggplot(data=portfolio,aes(y=Zpart_rich,x=rich))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Richness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

i19<-ggplot(data=portfolio,aes(y=Zpart_depth,x=Depth))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="z-value",x="Depth")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

i20<-ggplot(data=portfolio,aes(y=Zpart_depth,x=Depth))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Depth")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

i21<-ggplot(data=portfolio,aes(y=Zpart_depth,x=Depth))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Depth")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

i22<-ggplot(data=portfolio,aes(y=Zpart_sbt,x=SBT))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="z-value",x="SBT")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

i23<-ggplot(data=portfolio,aes(y=Zpart_sbt,x=SBT))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="SBT")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

i24<-ggplot(data=portfolio,aes(y=Zpart_sbt,x=SBT))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="SBT")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

pdf(file="Z_cwm_int.pdf",width=12,height=8)
(i16+i17+i18)/(i19+i20+i21)/(i22+i23+i24)
dev.off()

#4.4# Univariate relationships for Synchrony partial effects

i25<-ggplot(data=portfolio,aes(y=SYNpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Synchrony",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

i26<-ggplot(data=portfolio,aes(y=SYNpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

i27<-ggplot(data=portfolio,aes(y=SYNpart_even,x=even))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Evenness")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

i28<-ggplot(data=portfolio,aes(y=SYNpart_tai,x=TAI))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Synchrony",x="TAI")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

i29<-ggplot(data=portfolio,aes(y=SYNpart_tai,x=TAI))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="TAI")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

i30<-ggplot(data=portfolio,aes(y=SYNpart_tai,x=TAI))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="TAI")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

i31<-ggplot(data=portfolio,aes(y=SYNpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Synchrony",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

i32<-ggplot(data=portfolio,aes(y=SYNpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

i33<-ggplot(data=portfolio,aes(y=SYNpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

pdf(file="SYN_cwm_int.pdf",width=12,height=8)
(i25+i26+i27)/(i28+i29+i30)/(i31+i32+i33)
dev.off()

#4.5# Univariate relationships for Evenness partial effects

i34<-ggplot(data=portfolio,aes(y=EVENpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Evenness",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

i35<-ggplot(data=portfolio,aes(y=EVENpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

i36<-ggplot(data=portfolio,aes(y=EVENpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

i37<-ggplot(data=portfolio,aes(y=EVENpart_chla,x=Chla))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Evenness",x="Chla")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

i38<-ggplot(data=portfolio,aes(y=EVENpart_chla,x=Chla))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Chla")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

i39<-ggplot(data=portfolio,aes(y=EVENpart_chla,x=Chla))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Chla")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

i40<-ggplot(data=portfolio,aes(y=EVENpart_sbt,x=SBTrange))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Evenness",x="SBTrange")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(G)")

i41<-ggplot(data=portfolio,aes(y=EVENpart_sbt,x=SBTrange))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="SBTrange")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(H)")

i42<-ggplot(data=portfolio,aes(y=EVENpart_sbt,x=SBTrange))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="SBTrange")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(I)")

i43<-ggplot(data=portfolio,aes(y=EVENpart_trawl,x=Trawl))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Evenness",x="Trawl")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(J)")

i44<-ggplot(data=portfolio,aes(y=EVENpart_trawl,x=Trawl))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="Trawl")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(K)")

i45<-ggplot(data=portfolio,aes(y=EVENpart_trawl,x=Trawl))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="Trawl")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(L)")

pdf(file="EVEN_cwm_int.pdf",width=12,height=8)
(i34+i35+i36)/(i37+i38+i39)/(i40+i41+i42)/(i43+i44+i45)
dev.off()

#4.6# Univariate relationships for Richness partial effects

i46<-ggplot(data=portfolio,aes(y=RICHpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Richness",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(A)")

i47<-ggplot(data=portfolio,aes(y=RICHpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

i48<-ggplot(data=portfolio,aes(y=RICHpart_chla,x=ChlaCV))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="ChlaCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(C)")

i49<-ggplot(data=portfolio,aes(y=RICHpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=Kgroup))+
  geom_smooth(method="lm",se=F,aes(col=Kgroup))+
  facet_wrap(~Kgroup)+
  labs(y="Richness",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(D)")

i50<-ggplot(data=portfolio,aes(y=RICHpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=L50group))+
  geom_smooth(method="lm",se=F,aes(col=L50group))+
  facet_wrap(~L50group)+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

i51<-ggplot(data=portfolio,aes(y=RICHpart_depth,x=DepthCV))+
  geom_point(size=3,alpha=0.4,aes(col=TLgroup))+
  geom_smooth(method="lm",se=F,aes(col=TLgroup))+
  facet_wrap(~factor(TLgroup,levels=c("Low TL","High TL")))+
  scale_color_manual(values=c("#00BFC4","#F8766D"))+
  labs(y="",x="DepthCV")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(F)")

pdf(file="RICH_cwm_int.pdf",width=10,height=5)
(i46+i47+i48)/(i49+i50+i51)
dev.off()


# ------------------------------------------------------ #
#5# BEF relationships using time series data for each survey
# NOTE THAT THIS CODE CAN NOT BE RUN BECAUSE THE RAW TIME SERIES DATA
# CAN NOT BE SHARED DUE TO PRIVACY REASONS. NONETHELESS, THE RESULTED COEFFICIENTS
# FROM THE LMEs ARE INCLUDED IN THE GENERAL DATA SET AND PLOTS CAN BE OBTAINED
# USING CODE IN SECTION 5.9

#5.1# Load all time series data

# allAreas<-read.csv2(file="areasdivall.csv",header=T,dec=",",sep=",")
# 
# head(allAreas)
# dim(allAreas)
# names(allAreas)

#5.2# Standardize predictors

# allAreas$richStd<-MyStd(allAreas$rich)
# allAreas$evenStd<-MyStd(allAreas$even)

#5.3# Model for Richness

# lme1<-lme(log(cpue_sum)~richStd,
#           random=~richStd|Area,
#           correlation=corAR1(form=~1|Area),
#           weights=varExp(),
#           data=allAreas)
# 
# summary(lme1)
# intervals(lme1)
# 
# coefRich<-as.data.frame(coef(lme1))
# coefRich$Area<-row.names(coefRich)
# colnames(coefRich)<-c("InterceptRich","SlopeRich","Area")

#5.4# Model for Evenness

# lme2<-lme(log(cpue_sum)~evenStd,
#           random=~evenStd|Area,
#           correlation=corAR1(form=~1|Area),
#           weights=varExp(),
#           data=allAreas)
# 
# summary(lme2)
# intervals(lme2)
# 
# coefEven<-as.data.frame(coef(lme2))
# coefEven$Area<-row.names(coefEven)
# colnames(coefEven)<-c("InterceptEven","SlopeEven","Area")

#5.5# Plot predicted results from the LMEs

# plme1<-allAreas %>% mutate(pred_dist=fitted(lme1)) %>% 
#   ggplot(aes(x=richStd,y=pred_dist,group=Area,col=Area))+
#   geom_point(data=allAreas,aes(x=richStd,y=log(cpue_sum)),alpha=0.4,col="gray60",size=0.1)+
#   geom_line(col="gray50")+
#   geom_abline(intercept=fixef(lme1)[1],slope=fixef(lme1)[2],linewidth=1.5)+
#   scale_y_continuous(expression(paste("ln-Abundance (ind × ",km^-2,")")))+
#   scale_x_continuous("Richness")+
#   theme_classic()+
#   background_grid()+
#   theme(legend.position="none",
#         axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(A)")
# 
# plme2<-allAreas %>% mutate(pred_dist=fitted(lme2)) %>% 
#   ggplot(aes(x=evenStd,y=pred_dist,group=Area,col=Area))+
#   geom_point(data=allAreas,aes(x=evenStd,y=log(cpue_sum)),alpha=0.4,col="gray60",size=0.1)+
#   geom_line(col="gray50")+
#   geom_abline(intercept=fixef(lme2)[1],slope=fixef(lme2)[2],linewidth=1.5)+
#   scale_y_continuous(expression(paste("ln-Abundance (ind × ",km^-2,")")))+
#   scale_x_continuous("Evenness")+
#   theme_classic()+
#   background_grid()+
#   theme(legend.position="none",
#         axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(D)")

# pdf(file="Abund_Div_LMEs.pdf",width=8,height=4)
# plme1+plme2
# dev.off()

#5.6# Residuals plots

# allAreas$residRichLME<-resid(lme1,type="n")
# allAreas$fitRichLME<-fitted(lme1)
# 
# allAreas$residEvenLME<-resid(lme2,type="n")
# allAreas$fitEvenLME<-fitted(lme2)
# 
# reLME1<-ggplot(data=allAreas,aes(x=fitRichLME,y=residRichLME))+
#   geom_point(alpha=0.4)+
#   geom_hline(yintercept=0)+
#   labs(y="Residuals",x="")+
#   theme_classic()+
#   background_grid()+
#   theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(A)")
# 
# reLME2<-ggplot(data=allAreas,aes(x=residRichLME))+
#   geom_histogram()+
#   labs(y="Count",x="")+
#   theme_classic()+
#   background_grid()+
#   theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(B)")
# 
# reLME3<-ggplot(data=allAreas,aes(x=fitEvenLME,y=residEvenLME))+
#   geom_point(alpha=0.4)+
#   geom_hline(yintercept=0)+
#   labs(y="Residuals",x="Fitted")+
#   theme_classic()+
#   background_grid()+
#   theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(C)")
# 
# reLME4<-ggplot(data=allAreas,aes(x=residEvenLME))+
#   geom_histogram()+
#   labs(y="Count",x="Residuals")+
#   theme_classic()+
#   background_grid()+
#   theme(axis.text=element_text(size=14),axis.title=element_text(size=16))+
#   ggtitle("(D)")
# 
# pdf(file="resid_LMMs.pdf",width=8,height=8)
# (reLME1|reLME2)/(reLME3|reLME4)
# dev.off()

#5.7# Merge both LMEs random effects

# allDataAreas<-merge(coefRich,coefEven,by.x="Area",by.y="Area")

#5.8# Merge with portfolio data

# head(portfolio)
# head(allDataAreas)
# 
# portfolio<-merge(portfolio,allDataAreas,by.x="System",by.y="Area",all=T)

#5.9# Explore relationships between random slopes and
# community properties and environment and plot relevant relationships

portfolio<-read.csv2(file="portfolioDataForGEB.csv",header=T,dec=",",sep=",")

head(portfolio)

portfolio %>% 
  select(c(12,14,15,18:28,30,33)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(SlopeRich)

portfolio %>% 
  select(c(12,14,15,18:28,32,33)) %>% 
  correlate(use="pairwise.complete.obs") %>% 
  focus(SlopeEven)

mr1<-ggplot(data=portfolio,aes(x=Depth,y=SlopeRich))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(data=portfolio[-6,],aes(x=Depth,y=SlopeRich),
              method="lm",se=F,col="gray50")+ # exclude Gulf of Lions for the LM
  scale_y_continuous("Effect of richness \non abundance")+
  scale_x_continuous("Depth")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(B)")

mr2<-ggplot(data=portfolio,aes(x=log(cpueME),y=SlopeRich))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(data=portfolio[-6,],aes(x=log(cpueME),y=SlopeRich),
              method="lm",se=F,col="gray50")+ # exclude Gulf of Lions for the LM
  scale_y_continuous("")+
  scale_x_continuous("ln-Abundance")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  guides(col=guide_legend(ncol=2,override.aes=list(size=1)))+
  ggtitle("(C)")

mr3<-ggplot(data=portfolio,aes(x=syn,y=SlopeEven))+
  geom_point(aes(col=Region),size=3)+
  geom_smooth(method="lm",se=F,col="gray50")+
  scale_y_continuous("Effect of evenness \non abundance")+
  scale_x_continuous("Synchrony")+
  scale_color_brewer(palette="Set1")+
  theme_classic()+
  background_grid()+
  theme(legend.position="none",
        axis.text=element_text(size=14),axis.title=element_text(size=16))+
  ggtitle("(E)")

mr1+mr2+mr3

# pdf(file="metareg_LMMs.pdf",width=11,height=7)
# plme1+mr1+mr2+plme2+mr3+plot_spacer()+plot_layout(ncol=3)
# dev.off()

